﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeDeRevisao2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostra_Click(object sender, EventArgs e)
        {
            float valor = float.Parse(txtValor.Text);
            float desconto;

            desconto = valor / 10;

            MessageBox.Show("Mostra valor do desconto " + desconto);

        }
    }
}
